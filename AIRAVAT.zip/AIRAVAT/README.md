# Closed-Eye-Detection-with-opencv
First, using 'haarcascade_frontalface_alt.xml' to check if there is a face or not.  Second, using 'haarcascade_eye_tree_eyeglasses.xml' to check if there is a opened-eye or not. Thus, If I get data: face(o) -> eyes(x), that is the person who is closing his eyes.
